<?php $banned_ips = array("0.0.0.0");
